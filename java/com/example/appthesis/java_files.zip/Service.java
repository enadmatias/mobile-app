package com.example.appthesis;

public class Service {
        int logoId;

        public Service(int logoId){
            this.logoId = logoId;
        }

    public int getLogoId() {
        return logoId;
    }

    public void setLogoId(int logoId) {
        this.logoId = logoId;
    }
}


