package com.example.appthesis;

public class PaypalConfig {
    public static final String PAYPAL_CLIENT_ID = "AQ_IHJsVz8z0OFXocGuCwZWB1u9dXHJor-PAh0nzy-cXbWxlfAeNht1xRkPFhS_W1jocUCvF0oNotXhq";
}
